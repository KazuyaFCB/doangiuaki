﻿#include <stdio.h>
#include <stdlib.h>

struct SV
{
	wchar_t mssv[10];
	wchar_t hovaten[30];
	wchar_t khoa[30];
	int year;
	wchar_t ngaysinh[10];
	//char hinhanhcanhan[30]; //link dẫn đến
	wchar_t motabanthan[1000];
};

void main()
{
	FILE * fp, *fpout;
	wchar_t ch, tempt[1000];
	int count = 0, demkitu = 0, sosinhvien = 0;
	bool flag = false;
	SV dssv[2];
	fp = fopen("MyText.txt", "r");
	while (!feof(fp))
	{
		ch = fgetwc(fp);
		tempt[demkitu] = ch;
		demkitu++;
		if (ch == ',' || ch == '\n' || ch == EOF)
		{
			count++;
			flag = true;
		}
		if (flag == true)
		{
			if (count == 1)
			{
				for (int i = 0; i < demkitu - 1; i++)
				{
					dssv[sosinhvien].mssv[i] = tempt[i];
					demkitu = 0;
				}
			}
			else if (count == 2)
			{
				for (int i = 0; i < demkitu - 1; i++)
				{
					dssv[sosinhvien].hovaten[i] = tempt[i];
					demkitu = 0;
				}
			}
			else if (count == 3)
			{
				for (int i = 0; i < demkitu - 1; i++)
				{
					dssv[sosinhvien].khoa[i] = tempt[i];
					demkitu = 0;
				}
			}
			else if (count == 4)
			{
				dssv[sosinhvien].year = 1999;
				demkitu = 0;
			}
			else if (count == 5)
			{
				for (int i = 0; i < demkitu - 1; i++)
				{
					dssv[sosinhvien].ngaysinh[i] = tempt[i];
					demkitu = 0;
				}
			}
			else if (count == 6)
			{
				for (int i = 0; i < demkitu - 1; i++)
				{
					dssv[sosinhvien].hovaten[i] = tempt[i];
					demkitu = 0;
				}
			}
			if (count == 6)
			{
				sosinhvien++;
				count = 0;
				demkitu = 0;
			}
			flag = false;
		}
	}
	fpout = fopen("newtext", "w+");
	for (int i = 0; i < 18;i++)
	    fwprintf(fpout, L"%lc",dssv[0].hovaten[i]);
	system("pause");
}